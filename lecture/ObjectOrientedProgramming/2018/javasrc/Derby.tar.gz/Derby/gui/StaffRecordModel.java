package gui;

import java.util.Date;
import java.util.Map;
import java.util.List;

/**
 *
 * @author tadaki
 */
public class StaffRecordModel
        extends javax.swing.table.AbstractTableModel {

    String titles[] = new String[]{
        "Staff ID", "Name", "Role", "Valid",
        "Reg Date", "Description", "Modify"
    };
    Class types[] = new Class[]{
        Integer.class, String.class, data.Role.class, Boolean.class,
        Date.class, String.class, Boolean.class
    };
    Object data[][];

    public void setData(List<data.Staff> staffList,
            Map<Integer, data.Role> roleList) {
        if (staffList == null || roleList == null) {
            return;
        }
        int n = staffList.size();
        int m = 7;
        data = new Object[n][m];
        for (int i = 0; i < n; i++) {
            data.Staff s = staffList.get(i);
            data[i][0] = s.getStaff_id();
            data[i][1] = s.getName();
            data[i][2] = roleList.get(s.getRole()).clone();
            data[i][3] = s.isValid();
            data[i][4] = s.getReg_date();
            data[i][5] = s.getDescription();
            data[i][6] = false;
        }
        fireTableChanged(null);
    }

    @Override
    public int getRowCount() {
        return data.length;
    }

    @Override
    public int getColumnCount() {
        return titles.length;
    }

    @Override
    public String getColumnName(int c) {
        return titles[c];
    }

    @Override
    public Class getColumnClass(int c) {
        return types[c];
    }

    @Override
    public Object getValueAt(int r, int c) {
        return data[r][c];
    }

    @Override
    public void setValueAt(Object aValue, int r, int c) {
        switch (c) {
            case 2:
                data[r][c] = ((data.Role) aValue).clone();
                data[r][6] = true;
                break;
            case 3:
                data[r][c] = (Boolean) aValue;
                data[r][6] = true;
                break;
            case 5:
                data[r][c] = (String) aValue;
                data[r][6] = true;
                break;
            default:
        }
        fireTableChanged(null);
    }

    @Override
    public boolean isCellEditable(int r, int c) {
        boolean b = true;
        switch (c) {
            case 0:
            case 1:
            case 4:
                b = false;
                break;
            default:
        }
        return b;
    }
}
