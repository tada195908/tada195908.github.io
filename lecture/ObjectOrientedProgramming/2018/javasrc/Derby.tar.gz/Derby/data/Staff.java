package data;

import java.util.Date;
/**
 *
 * @author tadaki
 */
public class Staff {
    private int staff_id;
    private String name;
    private int role;
    private boolean valid=false;
    private Date reg_date;
    private String description;

    public Staff(int staff_id, String name, int role, 
            Date reg_date, String description) {
        this.staff_id = staff_id;
        this.name = name;
        this.role = role;
        this.reg_date = reg_date;
        this.description = description;
    }

    public int getStaff_id() {
        return staff_id;
    }

    public String getName() {
        return name;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public Date getReg_date() {
        return reg_date;
    }

    public void setReg_date(Date reg_date) {
        this.reg_date = reg_date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
