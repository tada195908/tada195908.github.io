package data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author tadaki
 */
abstract public class AbstractData {

    /**
     * Roleの一覧
     */
    protected Map<Integer, Role> roles;
    /**
     * Staffの一覧
     */
    protected Map<Integer, Staff> staffs;

    /**
     * データ源への接続
     *
     * @throws java.lang.Exception
     */
    abstract public void connect() throws Exception;

    /**
     * データ源を閉じる
     *
     * @throws java.lang.Exception
     */
    abstract public void close() throws Exception;

    /*
     * Role に関する検索
     */
    /**
     * Role一覧を取得
     *
     * @throws java.lang.Exception
     */
    abstract public void getRoles() throws Exception;

    /**
     * Role一覧のマップのコピーを取得
     *
     * @return マップのコピー
     */
    public Map<Integer, Role> getRoleMap() {
        if (roles == null) {
            return null;
        }
        Map<Integer, Role> m = 
                Collections.synchronizedMap(new HashMap<Integer, Role>());
        roles.keySet().stream().forEach((i) -> {
            m.put(i, roles.get(i));
        });
        return m;
    }

    /**
     * Roleの一覧を配列で返す
     *
     * @return
     */
    public Role[] getRoleArray() {
        if (roles == null) {
            return null;
        }
        System.out.println(roles.keySet().size());
        Role[] v = new Role[roles.keySet().size()];
        int j = 0;
        for (Integer i : roles.keySet()) {
            v[j] = roles.get(i);
            j++;
        }
        return v;

    }

    /**
     * Roleを取得する
     *
     * @param i role_id
     * @return 取得したRole
     */
    public Role getRole(int i) {
        if (roles == null) {
            return null;
        }
        return roles.get(i);
    }

    /**
     * Roleの数を取得する
     *
     * @return Roleの数
     */
    public int getNumRoles() {
        return roles.size();
    }
    /*
     * Staff に関する検索
     */

    /**
     * Staff一覧をVectorとして取得する
     *
     * @return Staff一覧のVector
     */
    public List<Staff> getStaffList() {
        if (staffs == null) {
            return null;
        }
        List<Staff> s = Collections.synchronizedList(new ArrayList<Staff>());
        staffs.keySet().stream().forEach((i) -> {
            s.add(staffs.get(i));
        });
        return s;
    }

    /**
     * Staffを取得する
     *
     * @param i
     * @return 取得したStaff
     */
    public Staff getStaff(int i) {
        if (staffs == null) {
            return null;
        }
        return staffs.get(i);
    }

    /**
     * Staffの数を得る
     *
     * @return Staffの数
     */
    public int getNumStaffs() {
        return staffs.size();
    }

    /**
     * Staff一覧を取得
     *
     * @throws java.lang.Exception
     */
    abstract public void getStaffs() throws Exception;

    /**
     * Staffを追加
     *
     * @param s 追加するStaff
     * @throws java.lang.Exception
     */
    abstract int addStaff(Staff s) throws Exception;

    /**
     * Staffの情報を更新する
     *
     * @param s
     * @return 更新した数
     * @throws java.lang.Exception
     */
    abstract public int updateStaff(Staff s) throws Exception;
}
