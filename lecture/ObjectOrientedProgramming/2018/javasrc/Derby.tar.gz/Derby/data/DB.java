package data;

import java.sql.*;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author tadaki
 */
public class DB extends AbstractData {

    private Connection con = null;
    private String path = "C:/Users/tadaki/SkyDrive/ドキュメント"
            + "/lecture/ObjectOrientedProgramming/DB/";
    private String url;
    private String owner;

    /**
     * DBの指定
     *
     * @param dbname DBの名前
     * @param owner DBの所有者
     */
    public DB(String dbname, String owner) {
        url = "jdbc:derby:" + path + dbname;
        this.owner = owner;
    }

    /**
     * データ源への接続
     *
     * @throws SQLException
     */
    @Override
    public void connect() throws SQLException {
        con = DriverManager.getConnection(url);
    }

    /**
     * データ源を閉じる
     *
     * @throws SQLException
     */
    @Override
    public void close() throws SQLException {
        if (con == null) {
            return;
        }
        con.close();
    }

    /**
     * ***************************************************************
     * 検索
     */
    /**
     * Role一覧を取得
     *
     * @throws SQLException
     */
    @Override
    public void getRoles() throws SQLException {
        if (con == null) {
            return;
        }
        roles = Collections.synchronizedMap(new HashMap<Integer, Role>());

        ResultSet r = query("select * from roles");
        while (r.next()) {
            int id = r.getInt("role_id");
            Role role = new Role(id, r.getString("name"),
                    r.getString("description"));
            roles.put(id, role);
        }

    }

    /**
     * Staff一覧を取得
     *
     * @throws SQLException
     */
    @Override
    public void getStaffs() throws SQLException {
        if (con == null) {
            return;
        }
        ResultSet r = query("select * from staffs");
        staffs = new HashMap<>();

        while (r.next()) {
            int id = r.getInt("staff_id");
            Staff staff = new Staff(id, r.getString("name"), r.getInt("role"),
                    new Date(r.getTimestamp("reg_date").getTime()),
                    r.getString("description"));
            staff.setValid(r.getBoolean("valid"));
            staffs.put(id, staff);
        }

    }

    /**
     * **********************************************************************
     * 挿入
     */
    /**
     * Staffを追加
     *
     * @param s 追加するStaff
     * @return
     * @throws SQLException
     */
    @Override
    public int addStaff(Staff s) throws SQLException {
        StringBuilder b = new StringBuilder();
        b.append("insert into Staffs ");
        b.append("(name,role,valid,reg_date,description) ");
        b.append("values (");
        b.append("'").append(s.getName()).append("',");
        b.append("'").append(s.getReg_date()).append("',");
        b.append("'").append(s.isValid()).append("',");
        b.append("CURRENT_TIMESTAMP,");
        b.append("'").append(s.getDescription()).append("'");
        b.append(")");
        int k = insert(b.toString());
        return k;
    }

    /**
     * Staffの情報を更新する
     *
     * @param s
     * @return 更新した数
     * @throws SQLException
     */
    @Override
    public int updateStaff(Staff s) throws SQLException {
        StringBuilder b = new StringBuilder();
        b.append("update Staffs set ");
        b.append("role=").append(s.getRole()).append(",");
        b.append("valid=").append(s.isValid()).append(",");
        if (s.getDescription() != null) {
            b.append("description='").append(s.getDescription()).append("',");
        } else {
            b.append("description='',");
        }
        b.append("reg_date=CURRENT_TIMESTAMP ");
        b.append("where staff_id=").append(s.getStaff_id());
        System.out.println(b.toString());
        int k = insert(b.toString());
        System.out.println(k);
        return k;
    }

    /**
     * **********************************************************************
     * ツール
     */
    private ResultSet query(String sql) throws SQLException {
        if (con == null) {
            return null;
        }

        Statement select = con.createStatement();
        ResultSet resultSet = select.executeQuery(sql);
        return resultSet;
    }

    private int insert(String sql) throws SQLException {
        if (con == null) {
            return 0;
        }
        int count;
        Statement stm;

        /**
         * 自動コミットをオフにする
         */
        con.setAutoCommit(false);
        stm = con.createStatement();
        System.out.println(sql);
        count = stm.executeUpdate(sql);

        if (count != 0) {
            con.commit();
        } else {
            con.rollback();
        }

        return count;
    }

    /**
     * SQL文字列の無害化
     *
     * @param str
     * @return
     */
    static public String escapeQuote(String str) {
        return escapeQuote(str, "''");
    }

    /**
     * SQL文字列の無害化
     *
     * @param str
     * @param sub
     * @return
     */
    static public String escapeQuote(String str, String sub) {
        String ret;
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("'");
        java.util.regex.Matcher m = p.matcher(str);
        ret = m.replaceAll(sub);
        return ret;
    }
}
