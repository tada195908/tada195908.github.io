/**
 *
 * @author tadaki
 */
package xml;

import java.io.IOException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

public class XMLWriter {

    private String xmlFile = null;
    protected org.w3c.dom.Document document = null;

    public XMLWriter(String xmlFile) {
        this.xmlFile = xmlFile;
    }

    public String getXmlFile() {
        return xmlFile;
    }

    public void putDomDocument()
            throws IOException,
            TransformerConfigurationException,
            TransformerException {
        java.io.File file = new java.io.File(xmlFile);
        if (file == null) {
            System.exit(0);
        }
        boolean newFile = true;
        if (!file.exists()) {
            newFile = file.createNewFile();
        }
        if (newFile) {
            putDomDocumentSub(file);
        }
    }

    public void setDocument(org.w3c.dom.Document document) {
        this.document = document;
    }

    protected void putDomDocumentSub(java.io.File file)
            throws TransformerConfigurationException,
            TransformerException {
        javax.xml.transform.Source source =
                new javax.xml.transform.dom.DOMSource(document);
        javax.xml.transform.Result result =
                new javax.xml.transform.stream.StreamResult(file);

        // Write the DOM document to the file
        // Get Transformer
        javax.xml.transform.Transformer xformer =
                javax.xml.transform.TransformerFactory.newInstance().
                newTransformer();
        xformer.transform(source, result);
    }
}
