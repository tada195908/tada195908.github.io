/**
 *
 * @author tadaki
 */

package data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
abstract public class AbstractData {

    /**
     * Roleの一覧
     */
    protected HashMap<Integer, Role> roles;
    /**
     * Staffの一覧
     */
    protected HashMap<Integer, Staff> staffs;

    /**
     * データ源への接続
     * @throws java.lang.Exception
     */
    abstract public void connect() throws Exception;

    /**
     * データ源を閉じる
     * @throws java.lang.Exception
     */
    abstract public void close() throws Exception;

    /*
     * Role に関する検索
     */
    /**
     * Role一覧を取得
     * @throws java.lang.Exception
     */
    abstract public void getRoles() throws Exception;

    /**
     * Role一覧のマップのコピーを取得
     * @return マップのコピー
     */
    public HashMap<Integer, Role> getRoleMap() {
        if (roles == null) {
            return null;
        }
        HashMap<Integer, Role> m = new HashMap<Integer, Role>();
        for (Integer i : roles.keySet()) {
            m.put(i, roles.get(i));
        }
        return m;
    }

    /**
     * Role一覧のコピーをListとして返す
     * @return Role一覧のList
     */
    public List<Role> getRoleList() {
        if (roles == null) {
            return null;
        }
        List<Role> v = Collections.synchronizedList(new ArrayList<Role>());
        for (Integer i : roles.keySet()) {
            v.add(roles.get(i));
        }
        return v;
    }

    /**
     * Roleを取得する
     * @param i role_id
     * @return 取得したRole
     */
    public Role getRole(int i) {
        if (roles == null) {
            return null;
        }
        return roles.get(i);
    }

    /**
     * Roleの数を取得する
     * @return Roleの数
     */
    public int getNumRoles() {
        return roles.size();
    }
    /*
     * Staff に関する検索
     */

    /**
     * Staff一覧をListとして取得する
     * @return Staff一覧のList
     */
    public List<Staff> getStaffList() {
        if (staffs == null) {
            return null;
        }
        List<Staff> s = Collections.synchronizedList(new ArrayList<Staff>());
        for (Integer i : staffs.keySet()) {
            s.add(staffs.get(i));
        }
        return s;
    }

    /**
     * Staffを取得する
     * @param i
     * @return 取得したStaff
     */
    public Staff getStaff(int i) {
        if (staffs == null) {
            return null;
        }
        return staffs.get(i);
    }

    /**
     * Staffの数を得る
     * @return Staffの数
     */
    public int getNumStaffs() {
        return staffs.size();
    }

    /**
     * Staff一覧を取得
     * @throws java.lang.Exception
     */
    abstract public void getStaffs() throws Exception;

    /**
     * Staffを追加
     * @param s 追加するStaff
     * @throws java.lang.Exception
     */
    abstract public int addStaff(Staff s) throws Exception;

    /**
     * Staffの情報を更新する
     * @param s
     * @return 更新した数
     * @throws java.lang.Exception
     */
    abstract public int updateStaff(Staff s) throws Exception;
}
