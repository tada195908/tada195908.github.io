/**
 *
 * @author tadaki
 */
package data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Date;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

public class XMLData extends AbstractData {

    private final String ns = "http://udb.cc.saga-u.ac.jp";//Namespace
    private String path;
    private String roleXML;
    private String staffXML;
    private Document roleDocument;
    private Document staffDocument;

    /**
     * コンストラクタ
     * @param path xmlファイルを含むディレクトリ名
     */
    public XMLData(String path) {
        this.path = path;
        roleXML = path + java.io.File.separator + "Roles.xml";
        staffXML = path + java.io.File.separator + "Staffs.xml";
    }

    public void connect() throws Exception {
        //XML ファイルからデータ読み込み
        roleDocument = new xml.XMLReader(roleXML).getDocument();
        staffDocument = new xml.XMLReader(staffXML).getDocument();
    }

    public void close() throws Exception {
        update();
    }

    /**
     * ファイルへデータ書き出し
     * @throws java.lang.Exception
     */
    public void update() throws Exception {
        xml.XMLWriter writer = new xml.XMLWriter(staffXML);
        writer.setDocument(staffDocument);
        writer.putDomDocument();
    }

    public void getRoles() throws Exception {
        roles = new HashMap<Integer, Role>();
        //Roleタグの一覧取得
        NodeList list = roleDocument.getElementsByTagNameNS(ns, "Role");
        for (int i = 0; i < list.getLength(); i++) {
            //各Roleタグに対する処理
            Node node = list.item(i);
            String roleString =
                    node.getAttributes().getNamedItem("role_id").
                    getTextContent();
            int role_id = Integer.valueOf(roleString);
            Element e = (Element) node;
            Node nameNode = e.getElementsByTagNameNS(ns, "Name").item(0);
            String name = nameNode.getTextContent();
            Node descriptionNode =
                    e.getElementsByTagNameNS(ns, "Description").item(0);
            String description = descriptionNode.getTextContent();
            Role role = new Role(role_id, name, description);
            roles.put(role_id, role);
        }
    }

    @Override
    public void getStaffs() throws Exception {
        staffs = new HashMap<Integer, Staff>();
        //Staffタグの一覧取得
        NodeList list = staffDocument.getElementsByTagNameNS(ns, "Staff");
        for (int i = 0; i < list.getLength(); i++) {
            //各Staffタグに対する処理
            Node node = list.item(i);
            //属性一覧
            HashMap<String, Node> attr = new HashMap<String, Node>();
            attr.put("staff_id", node.getAttributes().
                    getNamedItem("staff_id"));
            attr.put("valid", node.getAttributes().getNamedItem("valid"));
            attr.put("reg_date", node.getAttributes().
                    getNamedItem("reg_date"));
            attr.put("role", node.getAttributes().getNamedItem("role"));

            int staff_id = Integer.valueOf(attr.get("staff_id").
                    getTextContent());
            boolean valid = Boolean.valueOf(attr.get("valid").
                    getTextContent());
            String dateString = attr.get("reg_date").getTextContent();
            Date reg_date = getDate(dateString);
            int role = Integer.valueOf(attr.get("role").getTextContent());
            //子タグ処理
            Element e = (Element) node;
            Node nameNode =
                    e.getElementsByTagNameNS(ns, "Name").item(0);
            String name = nameNode.getTextContent();
            Node descNode =
                    e.getElementsByTagNameNS(ns, "Description").item(0);
            String description = descNode.getTextContent();
            Staff staff =
                    new Staff(staff_id, name, role, reg_date, description);
            staff.setValid(valid);
            staffs.put(i, staff);
        }
    }

    public int addStaff(Staff s) throws Exception {
        //新しいタグの生成
        Element element = staffDocument.createElementNS(ns, "Staff");
        s.setReg_date(new Date());
        //属性の設定
        element.setAttribute("staff_id", String.valueOf(s.getStaff_id()));
        element.setAttribute("valid", String.valueOf(s.isValid()));
        element.setAttribute("reg_date", setDateString(s.getReg_date()));
        element.setAttribute("role", String.valueOf(s.getRole()));
        //子タグの生成
        Element name = staffDocument.createElementNS(ns, "Name");
        name.setTextContent(s.getName());
        Element description =
                staffDocument.createElementNS(ns, "Description");
        description.setTextContent(s.getDescription());
        //属性及び子タグを追加
        element.appendChild(name);
        element.appendChild(description);
        //ドキュメントツリーに追加
        NodeList list = staffDocument.getElementsByTagNameNS(ns, "Staffs");
        list.item(0).appendChild(element);
        return 1;
    }

    public int updateStaff(Staff s) throws Exception {
        NodeList list = staffDocument.getElementsByTagNameNS(ns, "Staff");
        Node node = null;
        //対応するタグを検索
        for (int i = 0; i < list.getLength(); i++) {
            Node tmp = list.item(i);
            String str =
                    tmp.getAttributes().getNamedItem("staff_id").
                    getTextContent();
            int staff_id = Integer.valueOf(str);
            if (staff_id == s.getStaff_id()) {
                node = tmp;
            }
        }
        if (node == null) {
            return 0;
        }
        s.setReg_date(new Date());
        Element element = (Element) node;
        element.setAttribute("valid", String.valueOf(s.isValid()));
        element.setAttribute("reg_date", setDateString(s.getReg_date()));
        element.setAttribute("role", String.valueOf(s.getRole()));
        Node descNode =
                element.getElementsByTagNameNS(ns, "Description").item(0);
        descNode.setTextContent(s.getDescription());
        return 1;
    }

    /**
     * XML中の日付表現をjava.util.Dateへ変換
     * @param dateString XML中の日付表現文字列  2009-01-23T01:10:32
     * @return 変換されたDate型インスタンス
     */
    private static Date getDate(String dateString) {
        Calendar calendar = Calendar.getInstance();
        //数字を切り出す
        String patternString = "(\\d+)";
        Matcher m = Pattern.compile(patternString).matcher(dateString);
        List<Integer> ints =
                Collections.synchronizedList(new ArrayList<Integer>());
        while (m.find()) {
            ints.add(Integer.valueOf(m.group()));
        }
        int year = ints.get(0);
        int month = ints.get(1) - 1;
        int d = ints.get(2);
        int h = ints.get(3);
        int min = ints.get(4);
        int s = ints.get(5);
        calendar.set(year, month, d, h, min, s);
        return calendar.getTime();
    }

    /**
     * java.util.Date型からXML 向け日付表現
     * @param date Date型インスタンス
     * @return 変換された文字列
     */
    private static String setDateString(Date date) {
        StringBuilder buf = new StringBuilder();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int h = calendar.get(Calendar.HOUR_OF_DAY);
        int m = calendar.get(Calendar.MINUTE);
        int s = calendar.get(Calendar.SECOND);
        buf.append(year);
        buf.append("-").append(padZero(month + 1, 2));
        buf.append("-").append(padZero(day, 2));
        buf.append("T").append(padZero(h, 2));
        buf.append(":").append(padZero(m, 2));
        buf.append(":").append(padZero(s, 2));
        return buf.toString();
    }

    /**
     * 桁数を指定して、前に0 を補完
     * @param v 数値
     * @param l 桁数
     * @return  0を補完した文字列
     */
    static public String padZero(int v, int l) {
        String str = String.valueOf(v);
        int pl = l - str.length();
        if (pl <= 0) {
            return str;
        }
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < pl; i++) {
            b.append("0");
        }
        b.append(str);
        return b.toString();
    }
}
