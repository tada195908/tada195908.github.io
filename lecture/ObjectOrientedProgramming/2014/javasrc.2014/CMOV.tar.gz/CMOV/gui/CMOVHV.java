/**
 * 車頭距離・速度空間のひょうじ
 * @author tadaki
 */
package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.util.List;

public class CMOVHV extends CMOVBase {

    private double hmax = 60.;
    private double vmax = 40.;
    private Point2D.Double origin = null;
    private double rho = 4.;
    private double offset = 50.;

    @Override
    public void setDrawParameter() {
        Dimension dimension = getPreferredSize();
        setFx((dimension.width - offset) / hmax);
        setFy(-(dimension.height - offset) / vmax);
        origin = new Point2D.Double(offset, dimension.height - offset);
        cmovSystem.setTstep(1);
        sleep = 10;
    }

    @Override
    public void showState() {
        initialize();
        cmovSystem.updatestate();
        if (image == null) {
            return;
        }
        Graphics2D g2 = (Graphics2D) image.getGraphics();
        Dimension dimension = getPreferredSize();
        List<cmov.CarVariables> cars = cmovSystem.getCarVariables();
        for (cmov.CarVariables c : cars) {
            double dx = c.getDx();
            double v = c.getV();
            g2.setPaint(evalColor(c.getAcceleration()));
            fillCircle(g2, getFx() * dx + origin.x - rho,
                    getFy() * v + origin.y - rho, 2 * rho);
        }

        drawLine(g2, origin.x, origin.y, (double) dimension.width, origin.y);
        drawLine(g2, origin.x, origin.y, origin.x, 0.);

        g2.setColor(Color.black);
        double dx = 0.1;
        int n = (int) (dimension.width / dx);
        for (int i = 0; i < n - 1; i++) {
            double x = i * dx;
            double y = cmov.Car.ovfunction(x);
            double xx = (i + 1) * dx;
            double yy = cmov.Car.ovfunction(xx);
            drawLine(g2, getFx() * x + origin.x, getFy() * y + origin.y,
                    getFx() * xx + origin.x, getFy() * yy + origin.y);
        }

    }
}
