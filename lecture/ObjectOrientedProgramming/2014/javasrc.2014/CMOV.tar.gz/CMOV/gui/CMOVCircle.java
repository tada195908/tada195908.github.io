/**
 * 車輌の位置を円形に表示する
 * @author tadaki
 */
package gui;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.util.List;

public class CMOVCircle extends CMOVBase {

    private double radius = 0.;
    private Point2D.Double origin = null;
    private double rho = 4.;

    @Override
    public void setDrawParameter() {
        Dimension dimension = getPreferredSize();
        double leng = cmovSystem.getLeng();
        radius = leng / 2. / Math.PI;
        setFx(dimension.width / 2 / 1.1 / radius);
        setFy(dimension.height / 2 / 1.1 / radius);
        origin = new Point2D.Double(1.1 * radius, 1.1 * radius);
        cmovSystem.setTstep(1);
        sleep = 10;
    }

    @Override
    public void showState() {
        initialize();
        cmovSystem.updatestate();
        if (image == null) {
            return;
        }
        Graphics2D g2 = (Graphics2D) image.getGraphics();
        double leng = cmovSystem.getLeng();
        List<cmov.CarVariables> cars =
                cmovSystem.getCarVariables();
        for (cmov.CarVariables c : cars) {
            double p = c.getX();
            double l = (p - leng) / leng;
            double x = radius * Math.cos(2 * Math.PI * l);
            double y = radius * Math.sin(2 * Math.PI * l);
            g2.setPaint(evalColor(c.getAcceleration()));
            fillCircle(g2, getFx() * (x + origin.x) - rho,
                    getFy() * (y + origin.y) - rho, 2 * rho);
        }
    }
}
