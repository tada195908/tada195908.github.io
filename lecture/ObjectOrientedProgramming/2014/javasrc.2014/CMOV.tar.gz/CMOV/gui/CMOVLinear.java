/**
 * 車輌位置を直線上に表示
 * @author tadaki
 */
package gui;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.util.List;

public class CMOVLinear extends CMOVBase {

    private final int tmax = 100;    //時間の上限

    @Override
    public void setDrawParameter() {
        Dimension dimension = getPreferredSize();
        double leng = cmovSystem.getLeng();
        setFx(1. * dimension.width / leng);
        setFy((double) getPreferredSize().height / tmax);
    }

    @Override
    public void showState() {
        t++;
        if (t == tmax) {
            initialize();
            t = 0;
        }
        cmovSystem.updatestate();
        if (image == null) {
            return;
        }
        Graphics2D g2 = (Graphics2D) image.getGraphics();
        List<cmov.Car> cars = cmovSystem.getCars();
        for (cmov.Car c : cars) {
            double xx = c.getPrevious().getX();
            double x = c.getCurrent().getX();
            if (x >= xx) {
                g2.setColor(getForeground());
                drawLine(g2, getFx() * xx, getFy() * (t - 1),
                        getFx() * x, getFy() * t);
            }
        }
    }
}
