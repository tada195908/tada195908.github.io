/**
 * 車輌変数のクラス
 * @author tadaki
 */
package cmov;

public class CarVariables {

    private double x;
    private double v;
    private double acceleration;
    private double dx;

    public CarVariables() {
        this(0., 0., 0., 0.);
    }

    public CarVariables(double x, double v, double acceleration, double dx) {
        this.x = x;
        this.v = v;
        this.acceleration = acceleration;
        this.dx = dx;
    }

    public void checkBoundary(double leng) {
        if (x > leng) {//周期境界条件
            x -= leng;
        }
    }

    @Override
    public CarVariables clone() {
        return new CarVariables(getX(), getV(), getAcceleration(), getDx());
    }

    /********** setters and getters *****************************************/
    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getV() {
        return v;
    }

    public void setV(double v) {
        this.v = v;
    }

    public double getAcceleration() {
        return acceleration;
    }

    public void setAcceleration(double acceleration) {
        this.acceleration = acceleration;
    }

    public double getDx() {
        return dx;
    }

    public void setDx(double dx) {
        this.dx = dx;
    }
}
