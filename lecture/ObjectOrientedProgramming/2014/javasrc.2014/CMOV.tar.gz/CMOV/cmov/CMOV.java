/**
 * 最適速度モデル
 * @author tadaki
 */
package cmov;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class CMOV {

    private final double leng = 2000.;       //系のサイズ
    private final double dt = 0.1;           //時間ステップ
    private List<Car> cars = null;//車輌リスト
    private int n;                            //車輌数
    private int tstep = 10;                 //一回のupdateで進める時間回数

    public CMOV() throws IllegalArgumentException {
        String m = "Number of cars must be larger than 10";
        throw new IllegalArgumentException(m);
    }

    public CMOV(int n) throws IllegalArgumentException {
        if (n <= 0) {
            String m = "Number of cars must be larger than 10";
            throw new IllegalArgumentException(m);
        }
        this.n = n;
        cmovinit();
    }

    /**
     * 初期状態生成
     */
    public void cmovinit() {
        cars = Collections.synchronizedList(new ArrayList<Car>());
        double dr = getLeng() / n;
        for (int i = 0; i < n; i++) {
            Car car = new Car();
            car.setX(i * dr);
            car.setV(0.);
            car.setLeng(getLeng());
            getCars().add(car);
        }
        int ii = (int) (0.4 * n);
        if (ii >= 0 && ii < getCars().size()) {
            getCars().get(ii).setX(ii * dr - 0.2 * dr);//摂動
        }
    }

    /**
     * 状態更新
     */
    public void updatestate() {
        //位置及び速度の保存
        for (int i = 0; i < n; i++) {
            getCars().get(i).saveValues();
        }

        for (int tt = 0; tt < tstep; tt++) {
            //移動準備
            for (int i = 0; i < n - 1; i++) {
                double xp = getCars().get(i + 1).getCurrent().getX();
                getCars().get(i).prepare(xp, dt);
            }
            double xp = getCars().get(0).getCurrent().getX();
            getCars().get(n - 1).prepare(xp, dt);
            //移動実行
            for (Car c : getCars()) {
                c.move();
            }
        }
    }
    /********** setters and getters *****************************************/

    public List<Car> getCars() {
        return cars;
    }

    public List<CarVariables> getCarVariables() {
        List<CarVariables> vList = Collections.synchronizedList(
                new ArrayList<CarVariables>());
        for (Car c : cars) {
            vList.add(c.getCurrent().clone());
        }
        return vList;
    }

    public void setTstep(int tstep) {
        this.tstep = tstep;
    }

    public double getLeng() {
        return leng;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n = 100;
        try {
            if (args.length > 0) {
                n = Integer.valueOf(args[0]);
            }
        } catch (NumberFormatException ex) {
            Logger.getLogger(CMOV.class.getName()).log(Level.SEVERE, null, ex);
            Logger.getLogger(CMOV.class.getName()).log(Level.INFO,
                    "Number of car is set to {0}", String.valueOf(n));
        }
        try {
            CMOV cmov = new CMOV(n);
            if (cmov != null) {
                for (int t = 0; t < 100; t++) {
                    cmov.updatestate();
                }
            }
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(CMOV.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
