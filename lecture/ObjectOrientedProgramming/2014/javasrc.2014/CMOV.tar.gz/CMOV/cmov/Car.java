/**
 * 最適速度模型に従う車両のクラス
 * @author tadaki
 */
package cmov;

public class Car {
    //車輌の変数
    private CarVariables current,  previous,  next;
    private double leng;//コースの長さ

    public Car() {
        current = new CarVariables();
        previous = new CarVariables();
    }

    /**
     * 移動準備
     * @param xp 先行車輌の位置
     * @param dt 時間ステップ
     */
    public void prepare(double xp, double dt) {
        if (xp < getCurrent().getX()) {
            xp += leng;
        }
        getCurrent().setDx(xp - getCurrent().getX());
        getCurrent().setAcceleration(
                CarParameters.alpha * (ovfunction(xp - getCurrent().getX())
                - getCurrent().getV()));
        double xnew = getCurrent().getX() + getCurrent().getV() * dt;
        double vnew = getCurrent().getV()
                + getCurrent().getAcceleration() * dt;
        next = new CarVariables(xnew, vnew,
                getCurrent().getAcceleration(), getCurrent().getDx());
    }

    /**
     * 移動の実行
     */
    public void move() {
        current = next.clone();
        getCurrent().checkBoundary(leng);
    }

    public void saveValues() {
        previous = getCurrent().clone();
    }

    static private double tanh(double y) {
        if (y > 0) {
            return (1. - Math.exp(-2 * y)) / (1. + Math.exp(-2 * y));
        } else {
            return (Math.exp(2 * y) - 1.) / (1. + Math.exp(2 * y));
        }
    }

    static public double ovfunction(double xd) {
        return (1./2.) * CarParameters.vmax
                * (tanh(2. * (xd - CarParameters.d) / CarParameters.w)
                + CarParameters.c);
    }

    /********** setters and getters *****************************************/
    public void setX(double x) {
        getCurrent().setX(x);
        getPrevious().setX(x);
    }

    public void setV(double v) {
        getCurrent().setV(v);
        getPrevious().setV(v);
    }

    public void setLeng(double leng) {
        this.leng = leng;
    }

    public CarVariables getCurrent() {
        return current;
    }

    public CarVariables getPrevious() {
        return previous;
    }
}
