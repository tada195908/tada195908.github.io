/**
 * CMOVモデルの定数群
 * @author tadaki
 */
package cmov;

public class CarParameters {
    //OV関数の定数
    static public final double vmax = 33.6;
    static public final double d = 25.;
    static public final double w = 23.3;
    static public final double c = 0.913;
    static public final double alpha = 2.;

    /**
     * インスタンス作成を許さない
     */
    private CarParameters(){}
}
