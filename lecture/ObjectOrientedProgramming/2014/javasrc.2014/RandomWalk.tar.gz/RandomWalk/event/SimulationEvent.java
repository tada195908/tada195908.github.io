package event;

import java.util.EventObject;

/**
 *
 * @author tadaki
 */
public class SimulationEvent extends EventObject {

    public static enum EventType {

        INITIALIZED, UPDATED;
    }
    private final EventType eventType;

    public SimulationEvent(Object source,EventType eventType) {
        super(source);
        this.eventType = eventType;
    }

    public EventType getEventType() {
        return eventType;
    }

}
