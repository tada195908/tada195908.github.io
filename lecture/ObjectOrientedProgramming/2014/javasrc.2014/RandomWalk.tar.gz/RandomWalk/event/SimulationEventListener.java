package event;

import java.util.EventListener;

/**
 *
 * @author tadaki
 */
public interface SimulationEventListener extends EventListener{
    public void stateChanged(SimulationEvent event);
}
