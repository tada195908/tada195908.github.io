
import java.awt.geom.Point2D;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.List;
import model.FileIO;
import model.PositionHistogram;
import model.Simulation;

/**
 *
 * @author tadaki
 */
public class CLIMain {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        int n = 100;
        int tmax = n;
        Simulation sys = new Simulation(n);
        for (int t = 0; t < tmax; t++) {
            sys.oneStep();
        }
        List<Point2D.Double> hist = PositionHistogram.getHist(sys.getWalkers());
        try (BufferedWriter writer = FileIO.openWriter("out.txt")) {
            for (Point2D.Double p : hist) {
                StringBuilder sb = new StringBuilder();
                sb.append(p.x).append(" ").append(p.y);
                writer.write(sb.toString());
                writer.newLine();
            }
        }

    }

}
