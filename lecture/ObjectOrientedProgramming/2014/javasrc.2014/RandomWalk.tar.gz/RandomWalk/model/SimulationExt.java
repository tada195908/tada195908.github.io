package model;

import event.SimulationEvent;
import event.SimulationEvent.EventType;
import event.SimulationEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Eventを発生するように拡張
 *
 * @author tadaki
 */
public class SimulationExt extends Simulation implements Runnable {

    private final int tmax = 10000;
    private volatile boolean running = false;
    private volatile int t;
    private final int updateTiming=10;

    private final List<SimulationEventListener> listeners;

    public SimulationExt(int n) {
        super(n);
        listeners = Collections.synchronizedList(new ArrayList<>());
    }

    public void addSimulationEventListener(SimulationEventListener o) {
        listeners.add(o);
    }

    public void removeSimulationEventListener(SimulationEventListener o) {
        listeners.remove(o);
    }

    public void clearSimulationEventListener() {
        listeners.clear();
    }

    protected void fireStateChanged(EventType eventType) {
        SimulationEvent e = new SimulationEvent(this, eventType);
        listeners.stream().forEach(p -> p.stateChanged(e));
    }

    @Override
    public List<Integer> oneStep() {
        List<Integer> list = super.oneStep();
        fireStateChanged(EventType.UPDATED);
        return list;
    }

    @Override
    public void initialize() {
        super.initialize();
        fireStateChanged(EventType.INITIALIZED);
    }

    public List<Integer> update(int n) {
        List<Integer> list = null;
        for (int i = 0; i < n; i++) {
            list = super.oneStep();
        }
        fireStateChanged(EventType.UPDATED);
        return list;
    }

    public void start() {
        running = true;
        t = 0;
    }

    public void stop() {
        running = false;
    }

    @Override
    public void run() {
        while (running) {
            update(updateTiming);
            t++;
            if (t > tmax) {
                running = false;
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
            }
        }
    }

}
