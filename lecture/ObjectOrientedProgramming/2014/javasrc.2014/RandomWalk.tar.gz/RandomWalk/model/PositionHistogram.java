package model;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author tadaki
 */
public class PositionHistogram {

    /**
     * 位置ヒストグラムの取得
     *
     * @param walkers
     * @return 位置とその位置に居るWalkerの比率のリスト
     */
    public static List<Point2D.Double> getHist(List<Walker> walkers) {
        List<Point2D.Double> list
                = Collections.synchronizedList(new ArrayList<Point2D.Double>());
        //最大変位の取得
        int xmax = 0;
        for (Walker w : walkers) {
            xmax = Math.max(xmax, Math.abs(w.getX()));
        }
        //ヒストグラムの生成
        int h[] = new int[2 * xmax + 1];
        for (Walker w : walkers) {
            int k = w.getX() + xmax;
            h[k]++;
        }
        //ヒストグラムをリストに変換
        //ヒストグラムも相対頻度に変換
        for (int i = 0; i < h.length; i++) {
            double x = i - xmax;
            double y = (double) h[i] / walkers.size();
            list.add(new Point2D.Double(x, y));
        }
        return list;
    }

}
