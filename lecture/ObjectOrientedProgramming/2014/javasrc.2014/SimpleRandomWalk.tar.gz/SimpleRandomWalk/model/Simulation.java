/**
 * 二次元酔歩モデルのシミュレーション
 * @author tadaki
 */
package model;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Simulation {
    private List<Walker> walkers=null;//Walkerのリスト

    public Simulation(int n) {
        walkers = Collections.synchronizedList(new ArrayList<Walker>());
        /** Walkerを初期化 */
        for(int i=0;i<n;i++){
            walkers.add(new Walker());
        }
    }

    /**
     * 一時間ステップの動作
     * @return 更新したWalkerの位置の一覧
     */
    public List<Point> oneStep(){
        List<Point> pList =
                Collections.synchronizedList(new ArrayList<Point>());
        for(Walker w:walkers){
            Point p = w.walk();
            pList.add(p);
        }
        return pList;
    }

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Simulation sys=new Simulation(100);
        for(int i=0;i<100;i++){
            sys.oneStep();
        }
        List<Point> pList = sys.oneStep();
        for(Point p:pList){
            System.out.print(p.x);
            System.out.print(" ");
            System.out.println(p.y);
        }
    }

}
