/**
 * Walkerのクラス
 * @author tadaki
 */
package model;

import java.awt.Point;

public class Walker {

    private Point p;//Walkerの位置

    public Walker(Point p) {
        this.p = p;
    }

    public Walker() {
        p = new Point(0, 0);
    }

    /**
     * 一時間ステップの移動
     * @return 新しい位置
     */
    public Point walk() {
        /** 4方向に等確率で移動する **/
        int r = (int) (4 * Math.random());
        int x = 2 * (r % 2) - 1;
        int y = 2 * (r / 2) - 1;
        x += p.x;
        y += p.y;
        p.move(x, y);
        return new Point(p);
    }
}
