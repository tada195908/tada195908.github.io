package data;

import java.sql.*;
import java.util.HashMap;

/**
 *
 * @author tadaki
 */
public class DB extends AbstractData {

    private Connection con = null;
    private String url;
    private String owner;

    /**
     * DBの指定
     * @param dbname DBの名前
     * @param owner  DBの所有者
     */
    public DB(String dbname, String owner) {
        url = "jdbc:postgresql://localhost:5432/" + dbname;
        this.owner = owner;
    }

    /**
     * データ源への接続
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public void connect() throws SQLException, ClassNotFoundException {
        Class.forName("org.postgresql.Driver");
        con = DriverManager.getConnection(url, owner, "");
    }

    /**
     * データ源を閉じる
     * @throws SQLException
     */
    public void close() throws SQLException {
        if (con == null) {
            return;
        }
        con.close();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        close();
    }

    /*****************************************************************
     * 検索
     */
    
    /**
     * Role一覧を取得
     * @throws SQLException
     */
    public void getRoles() throws SQLException {
        if (con == null) {
            return;
        }
        ResultSet r = query("select * from roles");
        roles = new HashMap<Integer, Role>();

        while (r.next()) {
            int id = r.getInt("role_id");
            Role role = new Role(id, r.getString("name"),
                    r.getString("description"));
            roles.put(id, role);
        }

    }

    /**
     * Staff一覧を取得
     * @throws SQLException
     */
    public void getStaffs() throws SQLException {
        if (con == null) {
            return;
        }
        ResultSet r = query("select * from staffs");
        staffs = new HashMap<Integer, Staff>();

        while (r.next()) {
            int id = r.getInt("staff_id");
            Staff staff = new Staff(id, r.getString("name"), r.getInt("role"),
                    new java.util.Date(r.getTimestamp("reg_date").getTime()),
                    r.getString("description"));
            staff.setValid(r.getBoolean("valid"));
            staffs.put(id, staff);
        }

    }

    /************************************************************************
     * 挿入
     */
    /**
     * Staffを追加
     * @param s 追加するStaff
     * @return
     * @throws SQLException
     */
    public int addStaff(Staff s) throws SQLException {
        StringBuffer b = new StringBuffer();
        b.append("insert into Staffs ");
        b.append("(name,role,valid,reg_date,description) ");
        b.append("values (");
        b.append("'" + s.getName() + "',");
        b.append("'" + String.valueOf(s.getReg_date()) + "',");
        b.append("'" + String.valueOf(s.isValid()) + "',");
        b.append("'NOW',");
        b.append("'" + s.getDescription() + "'");
        b.append(")");
        int k = insert(b.toString());
        return k;
    }

    /**
     * Staffの情報を更新する
     * @param s
     * @return 更新した数
     * @throws SQLException
     */
    public int updateStaff(Staff s) throws SQLException {
        StringBuffer b = new StringBuffer();
        b.append("update Staffs set ");
        b.append("role='" + String.valueOf(s.getRole()) + "',");
        b.append("valid='" + String.valueOf(s.isValid()) + "',");
        if (s.getDescription() != null) {
            b.append("description='" + s.getDescription() + "',");
        } else {
            b.append("description='',");
        }
        b.append("reg_date='NOW' ");
        b.append("where staff_id='" + String.valueOf(s.getStaff_id() + "'"));
        System.out.println(b.toString());
        int k = insert(b.toString());
        System.out.println(k);
        return k;
    }

    /************************************************************************
     * ツール
     */

    private ResultSet query(String sql) throws SQLException {
        if (con == null) {
            return null;
        }

        ResultSet resultSet = null;
        Statement select = con.createStatement();
        resultSet = select.executeQuery(sql);
        return resultSet;
    }

    private int insert(String sql) throws SQLException {
        if (con == null) {
            return 0;
        }
        int count = 0;
        Statement stm;

        /**
         * 自動コミットをオフにする
         */
        con.setAutoCommit(false);
        stm = con.createStatement();
        count = stm.executeUpdate(sql);

        if (count != 0) {
            con.commit();
        } else {
            con.rollback();
        }

        return count;
    }

    /**
     * SQL文字列の無害化
     * @param str
     * @return
     */
    static public String escapeQuote(String str) {
        return escapeQuote(str, "''");
    }

    /**
     * SQL文字列の無害化
     * @param str
     * @param sub
     * @return
     */
    static public String escapeQuote(String str, String sub) {
        String ret = null;
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("'");
        java.util.regex.Matcher m = p.matcher(str);
        ret = m.replaceAll(sub);
        return ret;
    }
}
