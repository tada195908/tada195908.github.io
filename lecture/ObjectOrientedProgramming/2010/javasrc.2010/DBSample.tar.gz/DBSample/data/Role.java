package data;

/**
 *
 * @author tadaki
 */
public class Role {

    private int role_id;
    private String name;
    private String description;

    public Role(int role_id, String name, String description) {
        this.role_id = role_id;
        this.name = name;
        this.description = description;
    }

    public int getRole_id() {
        return role_id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString(){
        return name;
    }

    @Override
    public Role clone(){
        return new Role(role_id, name, description);
    }
}
