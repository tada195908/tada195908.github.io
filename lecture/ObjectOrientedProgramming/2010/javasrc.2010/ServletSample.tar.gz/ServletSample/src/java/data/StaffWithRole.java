/**
 *
 * @author tadaki
 */
package data;

import xmlData.*;
import java.util.Date;

public class StaffWithRole {

    private xmlData.Staff staff;
    private xmlData.Role role;

    public StaffWithRole(final xmlData.Staff staff,
            xmlData.Role role) {
        this.staff = staff;
        this.role = role;
    }

    public xmlData.Staff getStaff() {
        return staff;
    }

    public int getStaff_id() {
        return staff.getStaff_id();
    }

    public String getName() {
        return staff.getName();
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
        staff.setRole(role.getRole_id());
    }

    public boolean isValid() {
        return staff.isValid();
    }

    public void setValid(boolean valid) {
        staff.setValid(valid);
    }

    public Date getReg_date() {
        return staff.getReg_date();
    }

    public void setReg_date(Date reg_date) {
        staff.setReg_date(reg_date);
    }

    public String getDescription() {
        return staff.getDescription();
    }

    public void setDescription(String description) {
        staff.setDescription(description);
    }
}
