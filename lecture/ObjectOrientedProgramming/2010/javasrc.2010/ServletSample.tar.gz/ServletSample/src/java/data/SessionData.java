/**
 *
 * @author tadaki
 */
package data;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.component.UIData;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import xmlData.Role;

public class SessionData {

    ExternalContext exCon = FacesContext.getCurrentInstance().
            getExternalContext();
    HttpServletRequest servletRequest =
            (HttpServletRequest) exCon.getRequest();
    private String clientIP = "unknown";
    private String user;
    private String validuser;
    private xmlData.AbstractData db;
    private List<xmlData.Role> roleList;
    private List<data.StaffWithRole> staffList;
    private int maxStaff = 0;
    private data.StaffWithRole staff = null;
    private UIData staffData = null;

    /** Creates a new instance of SessionData */
    public SessionData() {
        clientIP = servletRequest.getRemoteAddr();
        validuser = exCon.getInitParameter("adminUser");
    }

    /*********************** ボタンの動作など *******************/
    public String login() {
        String response = "LOGIN";
        System.err.println(validuser);
        if (!user.equals(validuser)) {
            response = "ERROR";
        } else {
            try {
                readData();
            } catch (Exception ex) {
                Logger.getLogger(SessionData.class.getName()).
                        log(Level.SEVERE, null, ex);
                response = "ERROR";
            }
        }
        return response;
    }

    public String selectStaff() {
        staff = (data.StaffWithRole) staffData.getRowData();
        return "EDITSTAFF";
    }

    public String updateStaff() {
        String s = "UPDATE";
        if (db == null) {
            s = "ERROR";
            return s;
        }
        try {
            db.updateStaff(staff.getStaff());
        } catch (Exception ex) {
            s = "ERROR";
            Logger.getLogger(SessionData.class.getName()).
                    log(Level.SEVERE, null, ex);
        }
        return s;
    }

    /***********************************************************/
    private void readData() throws Exception {
        String filename = exCon.getInitParameter("dataFolder");
        System.err.println(filename);
        File file = new File(filename);
        db = new xmlData.XMLData(file.getPath());
        db.connect();
        db.getRoles();
        db.getStaffs();
        HashMap<Integer, xmlData.Role> roleMap = db.getRoleMap();
        roleList = Collections.synchronizedList(
                new ArrayList<xmlData.Role>());
        for (xmlData.Role r : roleMap.values()) {
            roleList.add(r);
        }
        staffList = Collections.synchronizedList(
                new ArrayList<data.StaffWithRole>());
        for (xmlData.Staff s : db.getStaffList()) {
            staffList.add(new data.StaffWithRole(s,
                    roleMap.get(s.getRole())));
        }
        getMaxStaff(staffList);
    }

    private void getMaxStaff(List<data.StaffWithRole> staffList) {
        maxStaff = 0;
        for (data.StaffWithRole s : staffList) {
            maxStaff = Math.max(maxStaff, s.getStaff_id());
        }
    }

    /********************* 設定及び取得メソッド *******************/
    public String getClientIP() {
        return clientIP;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public StaffWithRole getStaff() {
        return staff;
    }

    public void setStaff(StaffWithRole staff) {
        this.staff = staff;
    }

    public UIData getStaffData() {
        return staffData;
    }

    public void setStaffData(UIData staffData) {
        this.staffData = staffData;
    }

    public List<data.StaffWithRole> getStaffList() {
        return staffList;
    }

    public List<Role> getRoleList() {
        return roleList;
    }
}
