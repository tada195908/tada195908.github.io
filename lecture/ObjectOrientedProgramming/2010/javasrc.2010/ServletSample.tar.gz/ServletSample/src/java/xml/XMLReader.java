/**
 *
 * @author tadaki
 */
package xml;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class XMLReader {

    private String xmlFile = null;
    private Document document = null;

    public XMLReader(String xmlFile) throws Exception {
        this.xmlFile = xmlFile;
        document = getDomDocument(xmlFile);
    }

    public  Document getDocument() {
        return document;
    }

    public NodeList getNodeList(String name) {
        return document.getElementsByTagName(name);
    }

    public String getXmlFile() {
        return xmlFile;
    }

    public final Document getDomDocument(String xmlFile) throws Exception {
        java.io.File file = null;
        file = new java.io.File(xmlFile);
        if (file == null) {
            System.exit(0);
        }
        return getDomDocument(file);
    }

    public Document getDomDocument(java.io.File file) throws Exception {
        document = DOMUtil.parse(file);
        return document;
    }
}
