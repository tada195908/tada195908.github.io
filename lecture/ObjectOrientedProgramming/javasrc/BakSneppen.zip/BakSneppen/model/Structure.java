package model;

import java.util.List;
import java.util.Set;

/**
 * 種の関係を記述
 *
 * @author tadaki
 */
public interface Structure {

    /**
     * 初期の種の一覧を設定する
     *
     * @param list
     */
    public void set(List<Species> list);

    /**
     * 隣接種の一覧を取得
     *
     * @param species
     * @return
     */
    public Set<Species> getNeibours(Species species);
}
