package model;

import event.BakSneppenEvent;
import event.BakSneppenEvent.EventType;
import event.BakSneppenEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author tadaki
 */
public class DynamicsExt extends Dynamics implements Runnable {

    private final List<BakSneppenEventListener> listeners;
    private volatile boolean running = false;

    public DynamicsExt(int n, Structure structure) {
        super(n, structure);
        listeners = Collections.synchronizedList(new ArrayList<>());
    }

    @Override
    public Species update() throws CloneNotSupportedException {
        Species clone = super.update();
        fireStateChanged(EventType.UPDATED);
        return clone;
    }

    protected void fireStateChanged(EventType eventType) {
        BakSneppenEvent e = new BakSneppenEvent(this, eventType);
        listeners.stream().forEach(p -> p.stateChanged(e));
    }

    public void addBakSneppenEventListener(BakSneppenEventListener o) {
        listeners.add(o);
    }

    public void removeBakSneppenEventListener(BakSneppenEventListener o) {
        listeners.remove(o);
    }

    public void clearBakSneppenEventListener(BakSneppenEventListener o) {
        listeners.clear();
    }

    public void start() {
        running = true;
    }

    public void stop() {
        running = false;
    }

    @Override
    public void run() {
        while (running) {
            try {
                update();
            } catch (CloneNotSupportedException ex) {
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
            }
        }
    }

}
