package model;

/**
 * Bak-Sneppenモデルにおける一つの種を表す：Camparableを実装
 *
 * @author tadaki
 */
public class Species implements Comparable<Species>, Cloneable {

    private double f;//適応度
    private int age;//生存時間

    /**
     * コンストラクタ：適応度をランダムに初期化
     */
    public Species() {
        f = Math.random();
        age = 0;
    }

    /**
     * 年齢をインクリメント
     */
    public void update() {
        age++;
    }

    /**
     * 他の種と適応度を比較
     * @param o
     * @return 
     */
    @Override
    public int compareTo(Species o) {
        int s = 0;
        if (this.f > o.f) {
            s = 1;
        }
        if (this.f < o.f) {
            s = -1;
        }
        return s;
    }

    /**
     * 種が絶滅し、新たな種に入れ替わる。適応度をランダムに初期化
     * @return 初期化された適応度
     */
    public double reBorn() {
        f = Math.random();
        age = 1;
        return f;
    }

    /**
     * コピーを生成
     *
     * @return
     * @throws CloneNotSupportedException
     */
    @Override
    public Species clone() throws CloneNotSupportedException {
        return (Species) super.clone();
    }

    public int getAge() {
        return age;
    }

    public double getF() {
        return f;
    }
}
