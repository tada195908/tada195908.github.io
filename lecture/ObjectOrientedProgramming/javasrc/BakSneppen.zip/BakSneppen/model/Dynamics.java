package model;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import utils.Histogram;


/**
 * 観測過程が上書きされたBak Sneppen モデル
 *
 * @author tadaki
 */
public class Dynamics extends BaseDynamics {

    private double fitnessThreshold = 0.;//閾値
    //閾値変化の履歴
    private final List<Point2D.Double> thresholdUpdateHistory;
    private int t = 0;//時刻
    //絶滅した種の適応度ヒストグラム
    private Histogram extinctHistogram;
    private final List<Integer> durationList;

    /**
     * コンストラクタ
     *
     * @param n 種の数
     * @param structure 種の関係
     */
    public Dynamics(int n, Structure structure) {
        super(n, structure);
        thresholdUpdateHistory = Collections.synchronizedList(new ArrayList<>());
        thresholdUpdateHistory.add(new Point2D.Double(0., 0.));
        durationList = Collections.synchronizedList(new ArrayList<>());
    }

    /**
     * 絶滅した種の適応度のヒストグラムを生成
     *
     * @param m binの数
     */
    public void setExtinctHistgram(int m) {
        extinctHistogram = new Histogram(0., 1., 1. / m);
    }

    /**
     * 状態更新
     *
     * @return 絶滅した種の適応度を返す
     * @throws java.lang.CloneNotSupportedException
     */
    @Override
    public Species update() throws CloneNotSupportedException {
        Species clone = super.update();
        t++;
        checkThresholdUpdate(clone);
        extinctHistogram.put(clone.getF());
        if (!super.isInAvaranche()) {
            durationList.add(super.getLastDuration());
        }
        return clone;
    }

    /**
     * 絶滅種の適応度を調べ、閾値履歴を更新する
     *
     * @param min
     * @return
     */
    private boolean checkThresholdUpdate(Species min) {
        boolean newThreshold = false;
        if (min.getF() > fitnessThreshold) {//閾値更新
            newThreshold = true;
            fitnessThreshold = min.getF();
            thresholdUpdateHistory.add(
                    new Point2D.Double((double) t, fitnessThreshold));
        }
        return newThreshold;
    }

    /**
     * 継続時間の頻度分布を求める
     *
     * @return
     */
    public List<Point2D.Double> analyzeDurationLength() {
        int max = durationList.stream().reduce(0, (a, k) -> Math.max(a, k));
        int m = Math.max((int) Math.log10(max) - 2, 0);
        int binSize = (int) Math.pow(10., (double) m);
        Histogram hist = new Histogram(0, max, binSize);
        durationList.stream().forEach(k -> hist.put(k));
        return hist.getHistData();
    }

    public List<Point2D.Double> getThresholdUpdateHistory() {
        return thresholdUpdateHistory;
    }

    public Histogram getExtinctHistogram() {
        return extinctHistogram;
    }

    public List<Integer> getDurationList() {
        return durationList;
    }

}
