package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import utils.BinaryHeap;
import java.util.Set;

/**
 * Bak Sneppenモデルの基礎モデル
 *
 * @author tadaki
 */
public class BaseDynamics {

    private final BinaryHeap<Species> speciesList;//種のヒープ
    private final Structure structure;//種の依存関係
    protected Set<Species> neighbours = null;//一回の絶滅に関与した種のリスト
    private int duration = 1;
    private int lastDuration = 1;
    private boolean inAvaranche = false;

    /**
     * コンストラクタ
     *
     * @param n 種の数
     * @param structure 種の関係
     */
    public BaseDynamics(int n, Structure structure) {
        speciesList = new BinaryHeap<>();
        for (int i = 0; i < n; i++) {
            speciesList.add(new Species());
        }
        this.structure = structure;
        structure.set(speciesList.getList());
    }

    /**
     * 状態更新
     *
     * @return 絶滅した種のコピーを返す
     * @throws java.lang.CloneNotSupportedException
     */
    public Species update() throws CloneNotSupportedException {
        //全ての種の年齢を1増やす
        speciesList.getList().stream().forEach(s -> s.getAge());
        Species minimum = speciesList.peek();
        if (neighbours != null && neighbours.contains(minimum)) {
            //今回の最低適応度の種が前回の新生種の場合は絶滅連鎖
            duration++;
            inAvaranche = true;
        } else {//新たな絶滅の開始
            lastDuration = duration;
            duration = 1;
            inAvaranche = false;
        }
        Species clone = minimum.clone();//最低適応度の種のコピー

        neighbours = structure.getNeibours(minimum);//隣接種
        neighbours.add(minimum);
        //絶滅対象の種の処理
        neighbours.stream().forEach(
                s -> {
                    double fOld = s.getF();
                    double fNew = s.reBorn();
                    //ヒープ処理
                    if (fOld > fNew) {
                        speciesList.reduceValue(s);
                    } else {
                        speciesList.raiseValue(s);
                    }
                });

        return clone;
    }

    public int getLastDuration() {
        return lastDuration;
    }

    public boolean isInAvaranche() {
        return inAvaranche;
    }

    public List<Species> getSpecies() {
        return speciesList.getList();
    }

    public List<Double> getFitness() {
        List<Double> list = Collections.synchronizedList(new ArrayList<>());
        speciesList.getList().stream().forEachOrdered(s -> list.add(s.getF()));
        return list;
    }
}
