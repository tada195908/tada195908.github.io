package event;

import java.util.EventObject;

/**
 * シミュレーションを行なうクラスが生成するイベント
 * @author tadaki
 */
public class BakSneppenEvent extends EventObject {

    //イベントの種類
    public static enum EventType {

        INITIALIZED, //初期化
        UPDATED;//更新
    }
    
    private final EventType eventType;

    public BakSneppenEvent(Object source,EventType eventType) {
        super(source);
        this.eventType = eventType;
    }

    public EventType getEventType() {
        return eventType;
    }

}
