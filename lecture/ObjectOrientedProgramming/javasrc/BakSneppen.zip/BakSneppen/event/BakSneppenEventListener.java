package event;

import java.util.EventListener;

/**
 * シミュレーションが生成するイベントのリスナーインターフェイス
 *
 * @author tadaki
 */
public interface BakSneppenEventListener extends EventListener {

    public void stateChanged(BakSneppenEvent event);
}
