package system;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import model.Species;
import model.Structure;


/**
 *
 * @author tadaki
 */
public class TwoDSystem implements Structure{
    private List<Species> cites=null;
    private  int n=0;

    @Override
    public void set(List<Species> list) {
        n = (int)Math.sqrt(list.size());
        cites = Collections.synchronizedList(new ArrayList<>());
        list.stream().forEach(s->cites.add(s));
    }

    @Override
    public Set<Species> getNeibours(Species species) {
        int k = cites.indexOf(species);
        Set<Species> neighbours = Collections.synchronizedSet(new HashSet<>());
        int x = k%n;
        int y = (int)(k/n);
        //Neuman 近傍:上下左右
        neighbours.add(cites.get(getSite(x,y+1)));//上
        neighbours.add(cites.get(getSite(x,y-1)));//下
        neighbours.add(cites.get(getSite(x-1,y)));//左
        neighbours.add(cites.get(getSite(x+1,y)));//右
        return neighbours;
    }
    
    private int getSite(int x,int y){
        x = (x+n)%n;
        y = (y+n)%n;
        return y*n+x;
    }
    
}
