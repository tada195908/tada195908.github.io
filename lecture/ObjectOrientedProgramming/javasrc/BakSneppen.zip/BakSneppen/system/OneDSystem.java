package system;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import model.Species;
import model.Structure;


/**
 * 1次元周期系
 * @author tadaki
 */
public class OneDSystem implements Structure{
    private List<Species> cites=null;

    @Override
    public void set(List<Species> list) {
        cites = Collections.synchronizedList(new ArrayList<>());
        list.stream().forEach(s->cites.add(s));
    }

    @Override
    public Set<Species> getNeibours(Species species) {
        int k = cites.indexOf(species);
        Set<Species> neighbours = Collections.synchronizedSet(new HashSet<>());
        int n = cites.size();
        neighbours.add(cites.get((k+1)%n));
        neighbours.add(cites.get((k-1+n)%n));
        return neighbours;
    }

}
