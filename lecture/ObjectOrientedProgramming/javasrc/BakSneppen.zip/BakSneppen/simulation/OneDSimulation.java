package simulation;

import java.io.IOException;
import model.Dynamics;
import system.OneDSystem;

/**
 *
 * @author tadaki
 */
public class OneDSimulation extends AbstractSymulation {

    /**
     * @param args the command line arguments
     * @throws java.lang.CloneNotSupportedException
     * @throws java.io.IOException
     */
    public static void main(String[] args)
            throws CloneNotSupportedException, IOException {
        int t = 100000;//総時間ステップ
        int numSite = 1024;//種の数
        int bin = 100;//絶滅頻度ヒストグラムのbinの数
        Dynamics sys = new Dynamics(numSite, new OneDSystem());
        sys.setExtinctHistgram(bin);
        for (int i = 0; i < t; i++) {//状態更新
            sys.update();
        }
        //結果出力
        outputHistgram(sys, "OneDSimulation");
        //閾値の変化履歴
        outputThreshold(sys, "OneDSimulation");
        //継続時間の長さの頻度
        outputDuration(sys, "OneDSimulation");
    }
}
