package simulation;

import java.awt.geom.Point2D;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.List;
import model.Dynamics;
import utils.FileIO;

/**
 *
 * @author tadaki
 */
public class AbstractSymulation {

    /**
     * 絶滅した（最低適応度であった）種の適応度のヒストグラム作成
     *
     * @param sys
     * @param prefix
     * @throws IOException
     */
    public static void outputHistgram(Dynamics sys, String prefix)
            throws IOException {
        try (BufferedWriter out
                = FileIO.openWriter(prefix + "-extinctHistogram.txt")) {
            for (Point2D.Double p : sys.getExtinctHistogram().getHistData()) {
                FileIO.writeSSV(out, p.x, p.y);
            }
        }
    }

    /**
     * /閾値の変化履歴
     *
     * @param sys
     * @param prefix
     * @throws IOException
     */
    public static void outputThreshold(Dynamics sys, String prefix)
            throws IOException {
        List<Point2D.Double> history = sys.getThresholdUpdateHistory();
        try (BufferedWriter outT
                = FileIO.openWriter(prefix + "-threshold.txt")) {
            FileIO.writeSSV(outT,
                    "#This data should be plotted with steps style");
            for (Point2D.Double p : history) {
                FileIO.writeSSV(outT, p.x, p.y);
            }
        }
    }

    /**
     * 継続時間の長さの頻度
     *
     * @param sys
     * @param prefix
     * @throws IOException
     */
    public static void outputDuration(Dynamics sys, String prefix)
            throws IOException {
        List<Point2D.Double> durationHist = sys.analyzeDurationLength();
        try (BufferedWriter outD
                = FileIO.openWriter(prefix + "-duration.txt")) {
            for (Point2D.Double p : durationHist) {
                FileIO.writeSSV(outD, p.x, p.y);
            }
        }

    }
}
