package utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Binary Heap : 最も小さいものがroot位置に来る
 * @author tadaki
 * @param <T>
 */
public class BinaryHeap<T> {

    private List<T> list;//データを保持するリスト(先頭はnull)
    //要素を比較する方法：TがComparableでない場合に使用
    private Comparator<T> comparator = null;
    private int n;//要素数

    /**
     * コンストラクタ：要素はインターフェイスComparableを実装していること
     *
     */
    public BinaryHeap() {
        list = Collections.synchronizedList(new ArrayList<T>());
        list.add(null);
        n = 0;
    }

    /**
     * コンストラクタ：比較方法を指定する場合 
     *
     * @param comparator
     */
    public BinaryHeap(Comparator<T> comparator) {
        this();
        this.comparator = comparator;
    }


    /**
     * 新しい要素を追加する
     *
     * @param t
     * @return
     */
    public boolean add(T t) {
        boolean b = list.add(t);
        if (b) {
            n++;
            shiftUp(n);
        }
        return b;
    }

    /**
     * 最小の要素を得る：削除しない
     *
     * @return
     */
    public T peek() {
        if (n == 0) {
            return null;
        }
        return list.get(1);
    }

    /**
     * 最小の要素を取り出し、削除する
     *
     * @return
     */
    public T poll() {
        T t = null;
        if (n == 0) {
            return t;
        }
        if (n == 1) {//残りの要素が一つ
            t = list.remove(n);
            n--;
        } else {
            T x = list.remove(n);
            t = list.get(1);
            n--;
            list.set(1, x);
            shiftDown(1);
        }
        return t;
    }

    /**
     * 特定の要素の値を小さくした場合の再配置
     *
     * @param t
     */
    public void reduceValue(T t) {
        int k = list.indexOf(t);
        shiftUp(k);
    }

    /**
     * 特定の要素の値を大きくした場合の再配置
     *
     * @param t
     */
    public void raiseValue(T t) {
        int k = list.indexOf(t);
        shiftDown(k);
    }

    /**
     * リストの取得:先頭のnullを除く
     *
     * @return
     */
    public List<T> getList() {
        int nn= list.size();
        return list.subList(1, nn);
    }

    public boolean isEmpty() {
        return (n == 0);
    }

    public boolean contains(T t) {
        return list.contains(t);
    }

    // *****************************************************************
    /**
     * あるk にあるobjectを上位の適切な位置に置く
     *
     * @param k
     */
    private void shiftUp(int k) {
        if (k > 1 && isLess(k, (int) (k / 2))) {
            int j = (int) (k / 2);
            swap(k, j);
            shiftUp(j);
        }
    }

    /**
     * あるk にあるobjectを下位の適切な位置に置く
     *
     * @param k
     */
    private void shiftDown(int k) {
        if (2 * k <= n) {
            int j = 2 * k;
            if (j < n && isLess(j + 1, j)) {
                j++;
            }
            if (isLess(k, j)) {
                return;
            }
            swap(k, j);
            shiftDown(j);
        }
    }

    @SuppressWarnings("unchecked")
    private boolean isLess(int i, int j) {
        int a;
        T x = list.get(i);
        T y = list.get(j);
        if (comparator == null
                && x instanceof Comparable && y instanceof Comparable) {
            a = ((Comparable) x).compareTo((Comparable) y);
        } else {
            a = comparator.compare(x, y);
        }
        return (a < 0);
    }

    private void swap(int i, int j) {
        T o = list.get(i);
        list.set(i, list.get(j));
        list.set(j, o);
    }
}
