import event.SimulationEvent;
import event.SimulationEventListener;
import java.awt.geom.Point2D;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.PositionHistogram;
import model.SimulationExt;

/**
 *
 * @author tadaki
 */
public class EventListenerMain implements SimulationEventListener {

    private final SimulationExt simulationExt;
    private final String fileNameBase;
    private int n;

    public EventListenerMain(SimulationExt simulationExt,
            String fileNameBase) {
        this.simulationExt = simulationExt;
        this.fileNameBase = fileNameBase;
        n = 0;
    }

    @Override
    public void stateChanged(SimulationEvent event) {
        List<Point2D.Double> hist
                = PositionHistogram.getHist(simulationExt.getWalkers());
        String filename = fileNameBase + String.valueOf(n) + ".txt";
        try (BufferedWriter out
                = utils.FileUtils.openWriter(filename)) {
            for (Point2D.Double p : hist) {
                utils.FileUtils.writeSSV(out, p.x, p.y);
            }
            out.close();
        } catch (IOException ex) {
            Logger.getLogger(EventListenerMain.class.getName()).
                    log(Level.SEVERE, null, ex);
        }
        n++;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n = 100;
        int t = 10;
        SimulationExt simulation = new SimulationExt(n);
        EventListenerMain sys = new EventListenerMain(simulation, "out");
        simulation.addSimulationEventListener(sys);
        for (int i = 0; i < n / t; i++) {
            simulation.update(t);
        }

    }

}
