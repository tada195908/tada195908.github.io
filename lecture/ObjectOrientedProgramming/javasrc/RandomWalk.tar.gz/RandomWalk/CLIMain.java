import java.awt.geom.Point2D;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.List;
import model.PositionHistogram;
import model.Simulation;

/**
 *
 * @author tadaki
 */
public class CLIMain {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        int n = 10000;
        int tmax = 100;
        Simulation sys = new Simulation(n);
        for (int t = 0; t < tmax; t++) {
            sys.oneStep();
        }
        List<Point2D.Double> plist
                = PositionHistogram.getHist(sys.getWalkers());
        try (BufferedWriter out
                = utils.FileUtils.openWriter("output.txt")) {
            for (Point2D.Double p : plist) {
                utils.FileUtils.writeSSV(out, p.x, p.y);
            }
            out.close();
        }

    }

}
