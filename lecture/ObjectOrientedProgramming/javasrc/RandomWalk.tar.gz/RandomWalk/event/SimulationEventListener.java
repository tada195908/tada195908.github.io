package event;

import java.util.EventListener;

/**
 * シミュレーションが生成するイベントのリスナーインターフェイス
 *
 * @author tadaki
 */
public interface SimulationEventListener extends EventListener {

    public void stateChanged(SimulationEvent event);
}
