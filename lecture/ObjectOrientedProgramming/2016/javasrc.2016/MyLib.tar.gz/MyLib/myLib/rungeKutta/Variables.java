package myLib.rungeKutta;

/**
 *
 * @author tadaki
 */
public class Variables {
    public double t;
    public double y[];
}
