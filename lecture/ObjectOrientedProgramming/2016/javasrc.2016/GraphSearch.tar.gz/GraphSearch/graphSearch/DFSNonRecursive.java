package graphSearch;

import graph.*;
import java.util.List;
import java.util.Stack;

/**
 * 深さ優先探索(非再帰版)
 *
 * @author tadaki
 */
public class DFSNonRecursive extends GraphSearch {

    public DFSNonRecursive(Graph graph) {
        super(graph);
    }

    @Override
    public List<Arc> doSearch(Node start) {
        initialize();
        nodeList.add(start);
        searchSub(start);
        return arcList;
    }

    @Override
    protected void searchSub(Node v) {
        Stack<Arc> stack = new Stack<>();
        List<Arc> arcs = graph.getArcs(v);
        if (arcs == null) {
            return;
        }
        for(int i=arcs.size()-1;i>=0;i--){
            stack.push(arcs.get(i));
        }
        while (!stack.isEmpty()) {
            Arc a = stack.pop();
            Node w = a.end;
            if (!nodeList.contains(w)) {
                nodeList.add(w);
                arcList.add(a);
                List<Arc> newArcs = graph.getArcs(w);
                if (newArcs != null) {
                    for(int i=newArcs.size()-1;i>=0;i--){
                        Arc aa = newArcs.get(i);
                        if(!nodeList.contains(aa.end)){
                            stack.push(aa);
                        }
                    }
                }
            }
        }
    }

}
