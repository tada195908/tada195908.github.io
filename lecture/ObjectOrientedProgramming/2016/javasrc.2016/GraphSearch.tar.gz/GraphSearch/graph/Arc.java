package graph;

/**
 *
 * @author tadaki
 */
public class Arc{
    public final Node head;
    public final Node end;
    public final String label;

    public Arc(Node head, Node end,  String label) {
        this.head = head;
        this.end = end;
        this.label = label;
    }
        public String toString(){return label;}

}
