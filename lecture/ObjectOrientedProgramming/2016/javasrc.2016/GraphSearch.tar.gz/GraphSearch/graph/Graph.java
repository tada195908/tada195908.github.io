package graph;

import java.util.List;
import java.util.Map;
import myLib.utils.Utils;

/**
 *
 * @author tadaki
 */
public abstract class Graph {

    private final List<Node> nodes;
    private final Map<Node, List<Arc>> node2arc;
    public final String title;

    public Graph(String title) {
        this.title = title;
        nodes = Utils.createList();
        node2arc = Utils.createMap();
    }

    public void addNode(Node node) {
        nodes.add(node);
    }

    public void addArc(Node from, Node to,  String label) {
        Arc arc = new Arc(from, to,label);
        if (!node2arc.containsKey(from)) {
            List<Arc> arcList = Utils.createList();
            node2arc.put(from, arcList);
        }
        node2arc.get(from).add(arc);
    }

    public List<Node> getNodes() {
        return nodes;
    }
    
    public List<Arc> getArcs(Node node){
        return node2arc.get(node);
    }
    abstract public void construct();
}
